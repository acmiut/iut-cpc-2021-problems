// Author: Ali Shahali
#include <bits/stdc++.h>
#include "testlib.h"
#pragma GCC optimize ("O2,unroll-loops")

using namespace std;

#define SZ(S) ((int)(S).size())

const int N=1005;

int n, m;
int A[N][N];
int B[N][N];

void readAns(InStream& stream){
	for (int i=1; i<=n; i++){
		string S=stream.readToken();
		if (SZ(S)!=m) stream.quitf(_wa, "wrong grid size");
		for (int j=0; j<m; j++){
			if (S[j]!='0' && S[j]!='1')
				stream.quitf(_wa, "grid should be of 0s and 1s");
			A[i][j+1]=S[j]-'0';
		}
	}
	for (int i=1; i<=n; i++){
		for (int j=1; j<=m; j++){
			int s=0;
			for (int x=i-1; x<=i+1; x++){
				for (int y=j-1; y<=j+1; y++){
					s+=A[x][y];
				}
			}
			if (B[i][j]!=s)
				stream.quitf(_wa, "wrong grid. cell (%d, %d) doesnt match", i, j);
		}
	}
}

int main(int argc, char* argv[]){
	registerChecker("mine-sweeper", argc, argv); // input  answer  output
	n=inf.readInt();
	m=inf.readInt();
	for (int i=1; i<=n; i++){
		string S=inf.readToken();
		for (int j=0; j<m; j++){
			B[i][j+1]=S[j]-'0';
		}
	}
	// cerr<<"n="<<n<<"  m="<<m<<"\n";
	// readAns(ans);
	// cerr<<"checked ans\n";
	readAns(ouf);

	quitf(_ok, "ok grid is valid");
	
	return 0;
}

